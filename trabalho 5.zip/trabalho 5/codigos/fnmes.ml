
(* This file was auto-generated based on "sintatico.messages". *)

(* Please note that the function [message] can raise [Not_found]. *)

let message =
  fun s ->
    match s with
    | 26 ->
        "<While em lugar indevido - 96>\n"
    | 88 ->
        "<Esperava-se um do, por\195\169m obteve-se um while - 95>\n"
    | 89 ->
        "<\",\" em lugar indevido - 94>\n"
    | 137 ->
        "<Esperava-se uma condi\195\167\195\163o, obteve-se uma string - 93>\n"
    | 0 ->
        "<\",\" em lugar indevido - 92>\n"
    | 6 ->
        "<While em lugar indevido - 91>\n"
    | 8 ->
        "<While em lugar indevido - 90>\n"
    | 7 ->
        "<Until em lugar indevido - 89>\n"
    | 12 ->
        "<End em lugar indevido - 88>\n"
    | 90 ->
        "<Return sem parametro - 87>\n"
    | 92 ->
        "<\",\" em lugar indevido - 86>\n"
    | 144 ->
        "<Return sem parametro - 85>\n"
    | 127 ->
        "<Return sem parametro - 84>\n"
    | 93 ->
        "<While em lugar indevido - 83>\n"
    | 94 ->
        "<While em lugar indevido - 82>\n"
    | 95 ->
        "<While em lugar indevido - 81>\n"
    | 111 ->
        "<While em lugar indevido - 80>\n"
    | 36 ->
        "<While em lugar indevido - 79>\n"
    | 37 ->
        "<Until em lugar indevido - 78>\n"
    | 51 ->
        "<While em lugar indevido - 77>\n"
    | 52 ->
        "<Until em lugar indevido - 76>\n"
    | 63 ->
        "<While em lugar indevido - 75>\n"
    | 64 ->
        "<Until em lugar indevido - 74>\n"
    | 65 ->
        "<While em lugar indevido - 73>\n"
    | 66 ->
        "<Until em lugar indevido - 72>\n"
    | 38 ->
        "<While em lugar indevido - 71>\n"
    | 39 ->
        "<Until em lugar indevido - 70>\n"
    | 67 ->
        "<While em lugar indevido - 69>\n"
    | 68 ->
        "<Until em lugar indevido - 68>\n"
    | 53 ->
        "<While em lugar indevido - 67>\n"
    | 54 ->
        "<Until em lugar indevido - 66>\n"
    | 43 ->
        "<While em lugar indevido - 65>\n"
    | 44 ->
        "<Until em lugar indevido - 64>\n"
    | 45 ->
        "<While em lugar indevido - 63>\n"
    | 46 ->
        "<Until em lugar indevido  - 62>\n"
    | 69 ->
        "<While em lugar indevido - 61>\n"
    | 70 ->
        "<Until em lugar indevido - 60>\n"
    | 71 ->
        "<While em lugar indevido - 59>\n"
    | 72 ->
        "<Until em lugar indevido - 58>\n"
    | 73 ->
        "<While em lugar indevido - esperava-se uma string - 57>\n"
    | 74 ->
        "<Until em lugar indevido - 56>\n"
    | 75 ->
        "<While em lugar indevido - 55>\n"
    | 76 ->
        "<Until em lugar indevido - 54>\n"
    | 40 ->
        "<While em lugar indevido (e n\195\163o se pode realizar exponencia\195\167\195\163o de strings) - 53>\n"
    | 77 ->
        "<While em lugar indevido - 52>\n"
    | 78 ->
        "<Until em lugar indevido - 51>\n"
    | 59 ->
        "<N\195\163o pode realizar divis\195\163o de strings (e while em lugar indevido) - 50>\n"
    | 60 ->
        "<N\195\163o pode realizar divis\195\163o de strings (e until em lugar indevido) - 49>\n"
    | 47 ->
        "<N\195\163o pode realizar divis\195\163o de strings (e While em lugar indevido) - 48>\n"
    | 48 ->
        "<Esperava-se divis\195\163o de inteiros, por\195\169m obteve-se duas strings (e until em lugar indevido) - 47>\n"
    | 49 ->
        "<Nao pode-se realizar divis\195\163o de strings (e until em lugar indevido) - 46>\n"
    | 50 ->
        "<Nao pode-se realizar divis\195\163o de strings (e until em lugar indevido) - 45>\n"
    | 55 ->
        "<Esperava-se uma string, por\195\169m obteve-se um while - 44>\n"
    | 56 ->
        "<Until em lugar indevido - 43>\n"
    | 112 ->
        "<Esperava-se uma string, por\195\169m obteve-se um while - 42>\n"
    | 116 ->
        "<\",\" em lugar indevido - 41>\n"
    | 61 ->
        "<While em lugar indevido - 40>\n"
    | 62 ->
        "<Until em lugar indevido - 39>\n"
    | 79 ->
        "<Esperava-se uma string, por\195\169m obteve-se um while - 38>\n"
    | 80 ->
        "<Until em lugar indevido - 37>\n"
    | 57 ->
        "<Esperava-se uma string, por\195\169m obteve-se um while - 36>\n"
    | 58 ->
        "<Until em lugar indevido - 35>\n"
    | 97 ->
        "<Declara\195\167\195\163o incorreta de if - 34>\n"
    | 98 ->
        "<Declara\195\167\195\163o incorreta de if - 33>\n"
    | 99 ->
        "<Esperava-se um end, por\195\169m obteve-se uma \",\" - 32>\n"
    | 133 ->
        "<Esperava-se um end, por\195\169m obteve-se EOF - 31>\n"
    | 131 ->
        "<Esperava-se um end, por\195\169m obteve-se uma \",\" - 30>\n"
    | 135 ->
        "<Esperava-se um end, por\195\169m obteve-se um else - 29>\n"
    | 31 ->
        "<Until em lugar indevido - 28>\n"
    | 32 ->
        "<Esperava-se um valor, por\195\169m obteve-se um while - 27>\n"
    | 85 ->
        "<Esperava-se um valor, por\195\169m obteve-se um while - 26>\n"
    | 86 ->
        "<Esperava-se um valor, por\195\169m obteve-se um while - 25>\n"
    | 129 ->
        "<\",\" em lugar indevido - 24>\n"
    | 13 ->
        "<Declaracao incorreta de fun\195\167\195\163o - 23>\n"
    | 14 ->
        "<Declaracao incorreta de fun\195\167\195\163o - 22>\n"
    | 15 ->
        "<Declaracao incorreta de fun\195\167\195\163o - 21>\n"
    | 16 ->
        "<Erro nos parametros da fun\195\167\195\163o - 20>\n"
    | 17 ->
        "<Erro nos parametros da fun\195\167\195\163o - 19>\n"
    | 20 ->
        "<Erro nos parametros da fun\195\167\195\163o - 18>\n"
    | 21 ->
        "<Erro nos parametros da fun\195\167\195\163o - 17>\n"
    | 24 ->
        "<\",\" em lugar indevido - 16>\n"
    | 25 ->
        "<function em posi\195\167\195\163o indevida - 15>\n"
    | 139 ->
        "<Esperava-se um \"end\" no final da fun\195\167\195\163o - 14>\n"
    | 146 ->
        "<\",\" em lugar indevido - 13>\n"
    | 100 ->
        "<Defini\195\167\195\163o incorreta do FOR - 12>\n"
    | 101 ->
        "<Defini\195\167\195\163o incorreta do FOR - 11>\n"
    | 102 ->
        "<Defini\195\167\195\163o incorreta do FOR - 10>\n"
    | 103 ->
        "<Defini\195\167\195\163o incorreta do FOR - 9>\n"
    | 104 ->
        "<Defini\195\167\195\163o incorreta do FOR - 8>\n"
    | 105 ->
        "<Defini\195\167\195\163o incorreta do FOR - 7>\n"
    | 106 ->
        "<Defini\195\167\195\163o incorreta do FOR - 6>\n"
    | 107 ->
        "<Defini\195\167\195\163o incorreta do FOR - 5>\n"
    | 108 ->
        "<Defini\195\167\195\163o incorreta do FOR - 4>\n"
    | 109 ->
        "<Defini\195\167\195\163o incorreta de FOR - 3>\n"
    | 33 ->
        "<\"(\" incorreto antes do while - 2>\n"
    | 35 ->
        "<While indevido - 1>\n"
    | _ ->
        raise Not_found
