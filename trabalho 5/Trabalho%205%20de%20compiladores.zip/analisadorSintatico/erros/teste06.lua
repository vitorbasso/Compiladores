function int main()
    int x
    int y

    x = 9

    for y = 0, 5, 1
        x = x + 1
    end

end