function int main()
    int num1
    int num2
    print("Digite o primeiro numero: ")
    num1 = io.read('*n')
    print("Digite o segundo numero: ")
    num2 = io.read('*n')

    if num1 > num2 then
        print("O primeiro número ")
	print(num1)
	print(" é maior que o segundo ")
	print(num2)
    else
        print("O segundo número ")
	print(num2)
	print(" é maior que o primeiro ")
	print(num1)
    end
    return 1
end

main()

