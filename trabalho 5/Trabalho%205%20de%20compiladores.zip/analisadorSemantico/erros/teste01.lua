function int main()
	int x
	float x

	return 1
end

main()
