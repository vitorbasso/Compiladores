function int main()
	int x
	float y

	x = 10
	y = 20.0

	if x == y then
		print("Igual")
	else
		print("Diferente")
	end
	return 1
end

main()
