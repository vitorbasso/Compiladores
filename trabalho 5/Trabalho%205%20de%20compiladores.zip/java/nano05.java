public class nano05{
    public static void main(String[] args){
        int n;
        n = 2;
        System.out.print(n);
    }
}