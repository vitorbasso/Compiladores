function int main()
	int x
	float y
	x = y + 1

	return 1
end

main()
