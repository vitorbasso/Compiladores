function main() int
end
