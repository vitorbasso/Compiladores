function main() int
    int n
    n = 1 - 2
    print(n)
    return n
end

main()

