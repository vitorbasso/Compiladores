function main() int
    int n
    n = 2
    print(n)
    return n
end

main()

