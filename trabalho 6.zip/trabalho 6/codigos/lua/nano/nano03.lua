function main() int
    int n
    n = 1
    return n
end

main()


