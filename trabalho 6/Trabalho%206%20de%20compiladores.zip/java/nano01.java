public class nano01{
    public static void main(String[] args){
        
    }
}