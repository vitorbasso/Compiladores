public class nano11{
    public static void main(String[] args){
        int n, m, x;
        n = 1;
        m = 2;
        x = 5;
        while(x > n){
            n = n + m;
            System.out.print(n);
        }
    }
}