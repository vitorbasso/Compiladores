public class nano09{
    public static void main(String[] args){
        int n;
        n = 1 + 1 / 2;
        if(n == 1){
            System.out.print(n);
        }else{
            System.out.print(0);
        }
    }
}