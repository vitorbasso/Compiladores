public class nano06{
    public static void main(String[] args){
        int n;
        n = 1 - 2;
        System.out.print(n);
    }
}