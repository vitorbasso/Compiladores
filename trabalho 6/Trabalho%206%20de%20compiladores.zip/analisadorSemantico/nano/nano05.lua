function int main()
    int n
    n = 2
    print(n)
    return n
end

main()

