function int main()
    int n
    n = 1 - 2
    print(n)
    return n
end

main()

