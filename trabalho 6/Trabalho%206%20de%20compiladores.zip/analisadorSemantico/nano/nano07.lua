function int main()
    int n
    n = 1
    if n == 1 then
        print(n)
    end
    return n
end

main()
