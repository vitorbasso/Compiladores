function int main()
	int n
	n = 1 + 2

	return n

end

main()

