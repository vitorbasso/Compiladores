function int main()
    float n
end

main()
