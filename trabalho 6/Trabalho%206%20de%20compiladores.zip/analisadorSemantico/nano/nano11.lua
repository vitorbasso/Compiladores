function int main()
    int n
    int m
    int x 
    n = 1
    m = 2
    x = 5
    while x > n do
        n = n + m
        print(n)
    end
   return 1
end

main()
