function int main()
    int n
    int m 
    n = 1 
    m = 2
    if n == m then
        print(n)
    else
        print(0)
    end
   return 1
end

main()
