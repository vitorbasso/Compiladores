function main()
    local n
    n = 1 - 2
    print(n)
end

main()