function main()
    local n
    n = 2
    print(n)
end

main()