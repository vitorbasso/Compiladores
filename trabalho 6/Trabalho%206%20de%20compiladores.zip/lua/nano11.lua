function main()
    local n, m, x 
    n, m, x = 1, 2, 5
    while x > n do
        n = n + m
        print(n)
    end
end

main()