function main() int
    float n
end

main()
