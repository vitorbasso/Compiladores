function main() int
    int n
    n = 1 + 1 / 2
    if n == 1 then
        print(n)
    else
        print(0)
    end
    return n
end

main()
