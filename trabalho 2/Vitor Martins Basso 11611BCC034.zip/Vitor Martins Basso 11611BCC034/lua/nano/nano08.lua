function main()
    local n
    n = 1
    if n == 1 then
        print(n)
    else
        print(0)
    end
end

main()