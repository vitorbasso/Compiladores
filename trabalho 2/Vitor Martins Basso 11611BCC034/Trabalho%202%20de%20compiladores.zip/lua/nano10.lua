function main()
    local n, m 
    n, m = 1, 2
    if n == m then
        print(n)
    else
        print(0)
    end
end

main()