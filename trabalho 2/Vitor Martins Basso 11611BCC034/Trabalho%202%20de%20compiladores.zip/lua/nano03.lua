function main()
    local n
    n = 1
end

main()