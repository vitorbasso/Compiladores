def paco(x):
  x = x + 1
    y = x + 2
    y = x + 3 + ( 4
 + 5)
  return x
