function int main()

    int x
    x = 9

    while if do
        x = x + 1
    end
end