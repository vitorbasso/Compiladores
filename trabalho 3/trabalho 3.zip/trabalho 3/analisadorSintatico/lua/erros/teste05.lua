function int main()
    int x
    x = 9
    if x == 9 then

end