function int main()
    local int n
    n = 1 + 2
end

