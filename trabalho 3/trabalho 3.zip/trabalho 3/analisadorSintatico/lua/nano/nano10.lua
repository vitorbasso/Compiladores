function int main()
    local int n
    local int m 
    n = 1 
    m = 2
    if n == m then
        print(n)
    else
        print(0)
    end
end
