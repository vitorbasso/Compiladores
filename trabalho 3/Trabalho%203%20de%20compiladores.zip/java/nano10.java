public class nano10{
    public static void main(String[] args){
        int n, m;
        n = 1;
        m = 2;
        if(n == m ){
            System.out.print(n);
        }else{
            System.out.print(0);
        }
    }
}