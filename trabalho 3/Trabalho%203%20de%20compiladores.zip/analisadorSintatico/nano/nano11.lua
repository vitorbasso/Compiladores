function int main()
    local int n
    local int m
    local int x 
    n = 1
    m = 2
    x = 5
    while x > n do
        n = n + m
        print(n)
    end
end

