function int main()
    int x
    x = 9

    return 

end