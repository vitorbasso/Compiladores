function int main()
	int x
	float y
	x = 10
	y = 20.0
	return y
end

main()
