public class nano02{
    public static void main(String[] args){
        int n;
    }
}