function int main(int x, int x)
	int x
	float y
	x = 10
	y = 20.0

	return 1
end

main()
