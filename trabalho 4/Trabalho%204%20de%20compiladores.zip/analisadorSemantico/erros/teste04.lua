int a, b

function int main(int z)
	int x
	float y
	x = 10
	y = 20.0
	return 1
end

main(a,b)
