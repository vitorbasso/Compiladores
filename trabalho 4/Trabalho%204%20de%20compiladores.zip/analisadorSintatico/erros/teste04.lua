function int main()
    int x

    x =

end