function int main()
    local int n
    n = 1
    if n == 1 then
        print(n)
    else
        print(0)
    end
end

