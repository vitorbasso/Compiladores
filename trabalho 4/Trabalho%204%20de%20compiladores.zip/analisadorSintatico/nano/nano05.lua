function int main()
    local int n
    n = 2
    print(n)
end

