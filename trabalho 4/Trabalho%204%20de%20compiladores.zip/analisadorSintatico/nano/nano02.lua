function int main()
    local int n
end
